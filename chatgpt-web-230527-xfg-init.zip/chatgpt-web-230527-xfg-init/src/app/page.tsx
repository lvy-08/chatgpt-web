import { Home } from "./components/home";

export default async function App() {
    return (
        <>
            <Home/>
        </>
    )
}
