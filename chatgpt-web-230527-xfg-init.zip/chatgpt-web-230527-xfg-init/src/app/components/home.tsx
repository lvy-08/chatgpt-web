import {inspect} from "util";
import styles from "./home.module.scss";

export function Home() {
    return (
        <div className={styles.container}>

        </div>
    );
}